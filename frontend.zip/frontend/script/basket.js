import navbarFooterLoad from "./navbarFooterLoad.js";
import logout from "./login.js"

$(document).ready(function() {
    history.pushState('', '', `/cart`);
    navbarFooterLoad();
    getBasket();
})

async function getBasket()
{
    let token = localStorage.getItem("token");
    if (!token) return;

    $("#basket-list").empty();

    await fetch("https://food-delivery.kreosoft.ru/api/basket", {
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    })
    .then((response) => {
        if (response.status == 401) {
            localStorage.removeItem("token");
            window.location.href="index.html";
        }
        return response.json();
    })
    .then((json) => {
        if (!json.length) $(".basket-card").addClass("d-none");
        let template = $(".basket-template");
        let count = 1;
        for (let dish of json)
        {
            let block = template.clone();
            block.attr("basket_main_id", dish.id);
            block.find(".button-delete").attr("basket_id", dish.id);
            block.find(".button-minus-basket").attr("basket_id", dish.id);
            block.find(".button-plus-basket").attr("basket_id", dish.id);
            block.find(".basket-num").text(count++ + ".");
            block.find(".img-basket").attr("src", dish.image);
            block.find(".basket-name").text(dish.name);
            block.find(".basket-price").text("Цена/шт: " + dish.price + " руб.");
            block.find(".item-count-basket").text(dish.amount);
            block.removeClass("d-none");
            $("#basket-list").append(block);
        }
    })
    .catch((error) => {
        console.log(error);
    })

    changeAmount();
    fullDelete();
}

async function addToBasket(id)
{
    let token = localStorage.getItem("token");
    if (!token) return;
    console.log("add");
    await fetch(`https://food-delivery.kreosoft.ru/api/basket/dish/${id}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    })
    .catch((error) => { console.log(error); })

    $("li[basket_main_id=" + id + "]").each(function() {
        let count = $(this).find(".item-count-basket").text();
        $(this).find(".item-count-basket").text(parseInt(count) + 1);
        console.log($(this).find(".item-count-basket").text());
    })
}

async function deleteFromBasket(id, params)
{
    let token = localStorage.getItem("token");
    if (!token) return;
    console.log("delete");
    await fetch(`https://food-delivery.kreosoft.ru/api/basket/dish/${id}` + params, {
    method: 'DELETE',
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${token}`
    }
    })
    .catch((error) => { console.log(error); })

    $("li[basket_main_id=" + id + "]").each(function() {
        let count = $(this).find(".item-count-basket").text();
        if (count == 1 || params == '?increase=false') $(this).addClass("d-none");
        $(this).find(".item-count-basket").text(parseInt(count) - 1);
        console.log($(this).find(".item-count-basket").text());
    })
}

function changeAmount()
{
    $(".button-minus-basket").on('click', function(e) {
        let id = $(this).attr("basket_id");
        deleteFromBasket(id, '?increase=true');
    })

    $(".button-plus-basket").on('click', function(e) {
        let id = $(this).attr("basket_id");
        addToBasket(id);
    })
}

function fullDelete()
{
    $('.button-delete').on('click', function(e) {
        let id = $(this).attr("basket_id");
        deleteFromBasket(id, '?increase=false');
    })
}

export default function overallAmount()
{
    let token = localStorage.getItem("token");
    if (!token) return;

    fetch("https://food-delivery.kreosoft.ru/api/basket", {
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    })
    .then((response) => {
        if (response.status == 401) localStorage.removeItem("token");
        return response.json();
    })
    .then((json) => {
        let amount = 0;
        for (let dish of json) amount += dish.amount;
        if (amount > 0) $(".basket-amount").text(amount);
    })
    .catch((error) => {
        console.log(error);
    })
}