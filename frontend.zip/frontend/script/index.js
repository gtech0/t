import logout from "./login.js"
import navbarFooterLoad from "./navbarFooterLoad.js";

$(document).ready(function(){
    navbarFooterLoad();
    if (!localStorage.getItem('params')) localStorage.setItem('params', '');
    loadDishes(localStorage.getItem('params'));
    urlParams();
});

async function loadDishes(params)
{
    history.pushState('', '', `/`);
    $('#main-dish-container').empty();

    keepSelected(params);
    let pageId = localStorage.getItem('id');
    await fetch(`https://food-delivery.kreosoft.ru/api/dish?${params}&page=${pageId}`)
    .then((response) => {
        if (response.ok) return response.json();
        
        localStorage.setItem('params', '');
        localStorage.setItem('id', 1);
        return console.log("error");
    })
    .then((json) => {
        paginationClone(json.pagination.count);
        let template = $('.dish-card-template');
        for (let dish of json.dishes)
        {
            let block = template.clone();
            block.attr("main_id", dish.id);
            block.find(".card-images").attr("data_id", dish.id);
            block.find(".basket-button").attr("data_id", dish.id);
            block.find(".button-minus-main").attr("data_id", dish.id);
            block.find(".button-plus-main").attr("data_id", dish.id);
            block.find(".dish-name").text(dish.name);
            block.find(".card-text-main").text(dish.description);
            block.find(".price").text("Цена - " + dish.price + "р");
            block.find(".img-dish").attr("src", dish.image);
            if (dish.vegetarian){block.find(".img-vegetarian").removeClass("d-none");}
            block.find('#rating' + Math.round(dish.rating) * 2).attr("checked", true);
            $('#dish-categories').find('option').each(function() {
                if (this.value === dish.category) {
                    block.find(".category").text("Категория блюда - " + this.text);
            }});
            block.removeClass("d-none");
            $('#main-dish-container').append(block);
            $("input[type=radio]:checked ~ label").css('color', '#FFBF00');
        }
        console.log(json.pagination)
    })
    .catch((error) => {
        console.log(error);
        $('.pagination').empty();
    })

    onPageClick();
    onCardClick();
    inBasketCheck();
    changeMainAmount();
    makePageActive();
}

function urlParams()
{
    let category = [['', '']];
    let selectedSort = [['sorting', 'NameAsc']];
    let checkedSwitch = [['vegetarian', 'false']];

    let oldParams = localStorage.getItem('params');
    console.log(oldParams)
    if (oldParams) {
        category = [];
        for (let p of oldParams.split('&'))
        {
            if (p.split('=')[0] == 'categories') {
                category.push(['categories', p.split('=')[1]]);
            }

            if (p.split('=')[0] == 'sorting') {
                selectedSort = [['sorting', p.split('=')[1]]];
            }

            if (p.split('=')[1] == 'true') {
                checkedSwitch = [['vegetarian', 'true']];
            }
        }
    }

    $("#dish-categories").change(function() {
        category = [];
        for (let cat of $(this).val()) {
            category.push(['categories', cat]);
        }
        console.log(category);
    });

    $("#sort-dish").change(function() {
        selectedSort = [['sorting', $(this).val()]];
        console.log(selectedSort);
    });

    $("#switch-vegetarian").change(function() {
        checkedSwitch = [["vegetarian", String($(this).is(':checked'))]];
        console.log(checkedSwitch);
    });

    $("#sort-button").on('click', function() {
        if (!localStorage.getItem('params')) localStorage.setItem('params', '');
        let params = [];
        let paramsLocal = [];
        paramsLocal = paramsLocal.concat(category, selectedSort, checkedSwitch);
        let searchParams = new URLSearchParams(paramsLocal).toString();
        localStorage.setItem('params', searchParams);

        let page = [['page', 1]];
        localStorage.setItem('id', 1);
        params = paramsLocal.concat(page);
        searchParams = new URLSearchParams(params).toString();
        console.log(searchParams)
        loadDishes(searchParams);
    });
}

function paginationClone(pages)
{
    let currentPage = localStorage.getItem('id');
    if (currentPage > pages) localStorage.setItem('id', 1);
    $('.pagination').empty();
    if (pages == 1) return;
    let ptemplate = $(".pag-page");
    let pblock = ptemplate.clone();
    pblock.find(".page-link").attr("id", "page=" + 1);
    pblock.find(".page-link").text('«');
    pblock.removeClass("d-none");
    $(".pagination").append(pblock);

    let i;
    for (i = 1; i <= pages; i++) {
        let pblock = ptemplate.clone();
        pblock.find(".page-link").attr("id", "page=" + i);
        pblock.find(".page-link").addClass("page" + i);
        pblock.find(".page-link").text(i);
        pblock.removeClass("d-none");
        $(".pagination").append(pblock);
    }

    pblock = ptemplate.clone();
    pblock.find(".page-link").attr("id", "page=" + (i - 1));
    pblock.find(".page-link").text('»');
    pblock.removeClass("d-none");
    $(".pagination").append(pblock);
}

function onPageClick()
{
    $('a.page-link').on('click', function(e) {
        if (!localStorage.getItem('params')) localStorage.setItem('params', '');
        console.log(this.id);
        loadDishes(localStorage.getItem('params') + '&' + this.id);
        localStorage.setItem('id', this.id.slice(5));
    })
}

function keepSelected(params)
{
    for (let p of params.split('&'))
    {
        if (p.split('=')[0] == 'categories') {
            $("#dish-categories").find('option').each(function() {
                if (this.value == p.split('=')[1]) $(this).attr('selected', 'selected');
            })
        }

        if (p.split('=')[0] == 'sorting') {
            $("#sort-dish").find('option').each(function() {
                if (this.value == p.split('=')[1]) $(this).attr('selected', 'selected');
            })
        }

        if (p.split('=')[1] == 'true') {
            $("#switch-vegetarian").attr('checked', 'checked');
        }
    }
}

function makePageActive()
{
    let page = localStorage.getItem('id');
    $(".page" + page).addClass('active');
}

function onCardClick()
{
    $('.card-images').on('click', function(e){
        let id = $(this).attr("data_id");
        console.log(id);
        localStorage.setItem('dish-id', id);
        window.location.href = "item.html";
    });
}

async function inBasketCheck()
{
    let token = localStorage.getItem("token");
    if (!token) return;

    await fetch("https://food-delivery.kreosoft.ru/api/basket", {
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    })
    .then((response) => {
        if (response.status == 401) localStorage.removeItem("token");
        return response.json();
    })
    .then((json) => {
        for (let dish of json)
        {
            $("div[main_id=" + dish.id + "]").each(function() {
                $(this).find(".basket-button").addClass("d-none");
                $(this).find(".change-amount").removeClass("d-none");
                $(this).find(".item-count-main").text(dish.amount);
                $(this).find(".price").addClass("w-75");
            })
        }
    })
    .catch((error) => {
        console.log(error);
    })
}

function changeMainAmount()
{
    $(".button-plus-main, .basket-button").on('click', async function(e) {
        let id = $(this).attr("data_id");
        let token = localStorage.getItem("token");
        if (!token) return;
        await fetch(`https://food-delivery.kreosoft.ru/api/basket/dish/${id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`
        }
        })
        .catch((error) => { console.log(error); })

        $("div[main_id=" + this.getAttribute("data_id") + "]").each(function() {
            let count = $(this).find(".item-count-main").text();
            if (!count) count = 0;
            $(this).find(".basket-button").addClass("d-none");
            $(this).find(".change-amount").removeClass("d-none");
            $(this).find(".item-count-main").text(parseInt(count) + 1);
            console.log($(this).find(".item-count-main").text());
        })
    })

    $(".button-minus-main").on('click', async function(e) {
        let token = localStorage.getItem("token");
        let id = $(this).attr("data_id");
        if (!token) return;
        await fetch(`https://food-delivery.kreosoft.ru/api/basket/dish/${id}?increase=true`, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`
        }
        })
        .catch((error) => { console.log(error); })

        $("div[main_id=" + this.getAttribute("data_id") + "]").each(function() {
            let count = $(this).find(".item-count-main").text();
            if (count == 1) {
                $(this).find(".basket-button").removeClass("d-none");
                $(this).find(".change-amount").addClass("d-none");
            }
            $(this).find(".item-count-main").text(parseInt(count) - 1);
            console.log($(this).find(".item-count-main").text());
        })
    })
}