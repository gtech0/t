import navbarFooterLoad from "./navbarFooterLoad.js";

$(document).ready(function() {
    let id = localStorage.getItem('dish-id');
    loadDish(id);
    checkAndSetRating(id);
})

function loadDish(id)
{
  $(".dish-card-container").empty();
  fetch(`https://food-delivery.kreosoft.ru/api/dish/${id}`)
  .then((response) => response.json())
  .then((json) => {
      let template = $('.item-card-template');
      let block = template.clone();
      block.find(".dish-name").text(json.name);
      block.find(".card-text-main").text(json.description);
      block.find(".price").text("Цена: " + json.price + " руб./шт");
      block.find(".img-dish").attr("src", json.image);
      if (json.vegetarian) block.find(".text-vegetarian").text("Вегетерианское");
      else block.find(".text-vegetarian").text("Не вегетерианское");
      block.find('#rating' + Math.round(json.rating) * 2 ).attr("checked", true);
      block.find(".category").text("Категория блюда - " + json.category);
      block.removeClass("d-none");
      $('.dish-card-container').append(block);
      $("input[type=radio]:checked ~ label").css('color', '#FFBF00');
  });
}

function checkAndSetRating(id)
{
  console.log(id);
  let token = localStorage.getItem("token");
  if (!token) return;
  
  fetch(`https://food-delivery.kreosoft.ru/api/dish/${id}/rating/check`, {
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': `Bearer ${token}`
  }
  })
  .then((response) => response.json())
  .then((json) => {
    console.log(json);
    if (json) setRating(id);
  })
  .catch((error) => {
    console.error('Error:', error);
  });
}

function setRating(id)
{
  let token = localStorage.getItem("token");

  $(".rating-item > input").on('click', function() {
    let rating = parseInt(this.value) / 2;

    fetch(`https://food-delivery.kreosoft.ru/api/dish/${id}/rating?ratingScore=${rating}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    })
    .then(() => {
      window.location.reload();
    })
    .catch((error) => {
      console.error('Error:', error);
    });
  });
}