import navbarFooterLoad from "./navbarFooterLoad.js";

$(document).ready(function() {
    let id = localStorage.getItem('dish-id');
    loadDish(id);
})

function loadDish(id)
{
    $(".dish-card-container").empty();
    fetch(`https://food-delivery.kreosoft.ru/api/dish/${id}`)
    .then((response) => response.json())
    .then((json) => {
        let template = $('.item-card-template');
        let block = template.clone();
        block.find(".dish-name").text(json.name);
        block.find(".card-text-main").text(json.description);
        block.find(".price").text("Цена: " + json.price + " руб./шт");
        block.find(".img-dish").attr("src", json.image);
        if (json.vegetarian) block.find(".text-vegetarian").text("Вегетерианское");
        else block.find(".text-vegetarian").text("Не вегетерианское");
        block.find('#rating' + Math.round(json.rating * 4) / 2).attr("checked", true);
        block.find(".category").text("Категория блюда - " + json.category);
        block.removeClass("d-none");
        $('.dish-card-container').append(block);
    });
}

function setRating()
{
    fetch("https://food-delivery.kreosoft.ru/api/account/profile", {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({
      
    }),
  })
  .catch((error) => {
    console.error('Error:', error);
  });
}