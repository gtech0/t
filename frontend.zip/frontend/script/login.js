import navbarFooterLoad from "./navbarFooterLoad.js";

$(document).ready(function() {
  navbarFooterLoad();
  $("#login-button").on("click", function() {
    login();
  })
  disablePassWhitespace();
});

$(document).on("click", "#exit-button", function(){
  logout();
});

function login()
{
  let email = $('#email-login').val();
  let password = $('#password-login').val();

  if (!email.match(/^[a-z0-9._+-]+@[a-z0-9.-]+\.[a-z]{1,}$/)) {
    alert("Incorrect email");
    return;
  }

  fetch("https://food-delivery.kreosoft.ru/api/account/login", {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
    body: JSON.stringify({
      "email": email,
      "password": password
    }),
  })
  .then((response) => {
    if (!response.ok) {
      $("#email-login").addClass("is-invalid");
      $("#password-login").addClass("is-invalid");
      return;
    }
    else {
      $("#email-login").removeClass("is-invalid");
      $("#password-login").removeClass("is-invalid");
      $("#email-login").addClass("is-valid");
      $("#password-login").addClass("is-valid");
      return response.json();
    }
  })
  .then((json) => {
    localStorage.setItem("token", json.token);
    localStorage.setItem("username", email);
    window.location.href="index.html";
  })
  .catch((error) => {
    console.error('Error:', error);
  });
}

export default async function logout()
{
  let token = localStorage.getItem("token");
  console.log("token");
  if (!token) return;

  await fetch("https://food-delivery.kreosoft.ru/api/account/logout", {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
  })
  .then(() => {
    localStorage.removeItem("token");
    window.location.href="index.html";
  })
  .catch((error) => {
    console.error('Error:', error);
  });
}

function disablePassWhitespace()
{
    $("#password-login").keydown((e) => {
        if (e.which == 32)
            return false;
    });
}