import overallAmount from "./basket.js";
export default function navbarFooterLoad() {
  $("header").load("navbar.html");
  $("footer").load("footer.html");
  overallAmount();
}