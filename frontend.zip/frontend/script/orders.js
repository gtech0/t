import navbarFooterLoad from "./navbarFooterLoad.js";

$(document).ready(function() {
    getOrders();
    goToCheckout();
})

function getOrders()
{
    let token = localStorage.getItem("token");
    if (!token) return;
    checkBasket();
    $(".orders-list").empty();
    fetch("https://food-delivery.kreosoft.ru/api/order", {
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    })
    .then((response) => {
        if (response.status == 401) localStorage.removeItem("token");
        return response.json();
    })
    .then((json) => {
        console.log(json.length);
        if (!json.length) $(".orders-card").addClass("d-none");
        let template = $(".orders-template");
        for (let order of json)
        {
            let block = template.clone();
            block.attr("order_id", order.id);
            block.find(".orders-time").text(order.orderTime);
            block.find(".orders-status").text(order.status);
            block.find(".orders-approx-time").text(order.deliveryTime);
            block.find(".orders-price").text(order.price);
            $(".orders-list").append(block);
        }
    })
    .catch((error) => {
        console.log(error);
    })
}

function checkBasket()
{
    let token = localStorage.getItem("token");
    if (!token) return;

    fetch("https://food-delivery.kreosoft.ru/api/basket", {
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    })
    .then((response) => {
        if (response.status == 401) localStorage.removeItem("token");
        return response.json();
    })
    .then((json) => {
        console.log(json.length);
        if (!json.length) $(".orders-container").addClass("d-none");
    })
    .catch((error) => {
        console.log(error);
    })
}

function goToCheckout()
{
    $(".orders-checkout").on('click', function() {
        window.location.href="purchase.html";
    })
}