import navbarFooterLoad from "./navbarFooterLoad.js";

$(document).ready(function() {
    history.pushState('', '', `/orders`);
    getOrders();
    goToCheckout();
})

$(document).on('click', '.orders-time-link', function() {
    let id = $(this).attr("order-time_id");
    localStorage.setItem('order-id', id);
    window.location.href="order.html";
})

$(document).on('click', ".confirm-delivery", function() {
    let id = $(this).attr("order_details_id");
    confirmDelivery(id);
})

function getOrders()
{
    let token = localStorage.getItem("token");
    if (!token) return;
    checkBasket();
    $(".orders-list").empty();
    fetch("https://food-delivery.kreosoft.ru/api/order", {
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    })
    .then((response) => {
        if (response.status == 401) {
            localStorage.removeItem("token");
            window.location.href="index.html";
        }
        return response.json();
    })
    .then((json) => {
        if (!json.length) $(".orders-card").addClass("d-none");
        let template = $(".orders-template");
        for (let order of json)
        {
            let block = template.clone();
            block.attr("order_id", order.id);
            block.find(".orders-time-link").attr("order-time_id", order.id);
            block.find(".confirm-delivery").attr("order_details_id", order.id);
            console.log(order.id)

            let date = order.orderTime.split("T")[0].split("-");
            block.find(".orders-time").text(date[2] + "." + date[1] + "." + date[0]);

            let status = "В процессе";
            console.log(order.status);
            if (order.status == "Delivered") {
                status = "Доставлен";
                block.find(".confirm-delivery").addClass("d-none");
            };
            block.find(".orders-status").text("Статус заказа - " + status);

            let delTime = order.deliveryTime.split("T");
            let delDate = delTime[0].replaceAll('-', '.');
            let delHour = delTime[1].slice(0, -3);
            let timeString;
            if (order.status == "InProcess") timeString = "Доставка ожидается в " + delHour;
            else timeString = "Доставлен: " + delDate + " " + delHour;
            block.find(".orders-approx-time").text(timeString);

            block.find(".orders-price").text(order.price + " руб.");
            block.removeClass("d-none");
            $(".orders-list").append(block);
        }
    })
    .catch((error) => {
        console.log(error);
    })
}

function checkBasket()
{
    let token = localStorage.getItem("token");
    if (!token) return;

    fetch("https://food-delivery.kreosoft.ru/api/basket", {
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    })
    .then((response) => {
        if (response.status == 401) {
            localStorage.removeItem("token");
            window.location.href="index.html";
        }
        return response.json();
    })
    .then((json) => {
        if (!json.length) $(".orders-container").addClass("d-none");
    })
    .catch((error) => {
        console.log(error);
    })
}

function goToCheckout()
{
    $(".orders-checkout").on('click', function() {
        window.location.href="purchase.html";
    })
}

export default function confirmDelivery(id)
{
    let token = localStorage.getItem("token");
    if (!token) return;
    console.log(id);
    fetch(`https://food-delivery.kreosoft.ru/api/order/${id}/status`, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${token}`
    }
    })
    .then((response) => {
        if (response.status == 401) {
            localStorage.removeItem("token");
            window.location.href="index.html";
        }
        if (response.ok) {
            window.location.reload();
        }
    })
    .catch((error) => {
        console.log(error);
    })
}