import navbarFooterLoad from "./navbarFooterLoad.js";
import logout from "./login.js"

$(document).ready(function() {
  navbarFooterLoad();
  phoneMask();
  phoneCheck();
  dateCheck();
  profileGet();
  $("#save-profile").on("click", () => {
    profileSet();
  })
})

function profileGet()
{
  let token = localStorage.getItem("token");
  if (!token) return;
  fetch("https://food-delivery.kreosoft.ru/api/account/profile", {
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
  })
  .then((response) => {
    console.log(response);
    if (response.status == 401) localStorage.removeItem("token");
    return response.json();
  })
  .then((json) => {
    console.log(json);
    $("#fio-profile").val(json.fullName);
    $("#email-profile").text(json.email);
    let birthDate = json.birthDate;
    let birthDateStripped = birthDate.substring(0, birthDate.indexOf('T'));
    console.log(birthDateStripped);
    $("#date-profile").val(birthDateStripped);
    if (json.gender == "Male") $("#sex-profile").text("мужчина");
    else $("#sex-profile").text("женщина");
    $("#address-profile").val(json.address);
    $("#phone-profile").val(json.phoneNumber);
  })
  .catch((error) => {
    console.error('Error:', error);
  });
}

function profileSet()
{
  let token = localStorage.getItem("token");
  if (!token || !nameCheck()) return;
  let fullName = $("#fio-profile").val();
  let birthDate = $("#date-profile").val();
  let gender;
  if ($("#sex-profile").text() == "мужчина") gender = "Male";
  else gender = "Female";
  let address = $("#address-profile").val();
  let phoneNumber = $("#phone-profile").val();
  console.log(fullName, birthDate, $("#sex-profile").text(), address, phoneNumber);

  fetch("https://food-delivery.kreosoft.ru/api/account/profile", {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({
      "fullName": fullName,
      "birthDate": birthDate,
      "gender": gender,
      "address": address,
      "phoneNumber": phoneNumber
    }),
  })
  .catch((error) => {
    console.error('Error:', error);
  });
}

function phoneMask() {
  $('#phone-profile').inputmask('+7 (999) 999-99-99', {"placeholder": "x", "clearMaskOnLostFocus": false});
}

function phoneCheck()
{
    let phoneLen = $('#phone-profile').val().replace(/[^0-9]/g, "").length;
    if (![0, 11].includes(phoneLen)) {
        alert("Incorrect phone number");
        $('#phone-profile').val('');
        return 0;
    }
    return 1;
}

function dateCheck() {
  $('#date-profile').on("change", function() {
      var date = new Date();
      var dateString = new Date(date.getTime() - (date.getTimezoneOffset() * 60000)).toISOString().split("T")[0];

      if (this.value > dateString) {
          this.value = dateString;
          alert("You can't born in the future!");
      }
  });
}

function nameCheck() {
  let fio = $("#fio-profile").val().trim();
  $("#fio-profile").val(fio);
  if (!fio.match(/^[а-яА-Яa-zA-Z ]+$/)) {
      alert("Enter your full name");
      return 0;
  }
  return 1;
}