import navbarFooterLoad from "./navbarFooterLoad.js";

$(document).ready(function() {
    getCustomer();
    getPurchaseList();
    $(".confirm-orders").on('click', function() {
        if (finalCheck()) confirmOrder();
    })
})

function getCustomer()
{
    let token = localStorage.getItem("token");
    if (!token) return;

    fetch("https://food-delivery.kreosoft.ru/api/account/profile", {
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    })
    .then((response) => {
        if (response.status == 401) localStorage.removeItem("token");
        return response.json();
    })
    .then((json) => {
        $("#customer-phone").val(json.phoneNumber);
        $("#customer-email").val(json.email);
        $("#customer-address").val(json.address);
    })
    .catch((error) => {
        console.log(error);
    })
}

function finalCheck()
{
    let check = checkDeliveryDate() + checkDeliveryAddress();
    if (check == 2) return 1;
}

function getPurchaseList()
{
    let token = localStorage.getItem("token");
    if (!token) return;

    $("#purchase-list").empty();

    fetch("https://food-delivery.kreosoft.ru/api/basket", {
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    })
    .then((response) => {
        if (response.status == 401) localStorage.removeItem("token");
        return response.json();
    })
    .then((json) => {
        if (!json.length) $(".purchase-card").addClass("d-none");
        let template = $(".purchase-template");
        let finalPrice = 0;
        for (let dish of json)
        {
            let block = template.clone();
            block.attr("purchase_main_id", dish.id);
            block.find(".img-purchase").attr("src", dish.image);
            block.find(".purchase-name").text(dish.name);
            block.find(".purchase-price").text("Цена: " + dish.price + " руб.");
            block.find(".purchase-amount").text("Количество: " + dish.amount + " шт.");
            block.find(".purchase-totalprice").text(dish.totalPrice + " руб.");
            finalPrice += dish.totalPrice;
            block.removeClass("d-none");
            $("#purchase-list").append(block);
        }
        $(".purchase-finalprice").text(finalPrice + " руб.");
    })
    .catch((error) => {
        console.log(error);
    })
}

function checkDeliveryDate()
{
    var date = new Date();
    var dateString = new Date(date.getTime() - (date.getTimezoneOffset() * 60000)).toISOString().split("Z")[0];
    console.log($('#customer-time').val(), dateString);
    if ($('#customer-time').val() < dateString || !$('#customer-time').val()) {
        
        $('#customer-time').val(dateString);
        alert("We can't deliver in the past :(");
        return 0;
    }
    return 1;
}

function checkDeliveryAddress()
{
    let address = $("#customer-address").val().trim();
    $("#customer-address").val(address);
    console.log($("#customer-address").val());
    if (!String(address).length) {
        alert("Enter your address");
        return 0;
    }
    return 1;
}

function confirmOrder()
{
    let token = localStorage.getItem("token");
    if (!token) return;
    
    let deliveryTime = $('#customer-time').val();
    let address = $('#customer-address').val();

    fetch("https://food-delivery.kreosoft.ru/api/order", {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({
        "deliveryTime": deliveryTime,
        "address": address
    }),
    })
    .then((response) => {
        if (response.status == 401) localStorage.removeItem("token");
        if (response.ok) {
            
        }
        return response.json();
    })
    .catch((error) => {
        console.log(error);
    })
}