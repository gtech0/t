import navbarFooterLoad from "./navbarFooterLoad.js";

$(document).ready(function() {
    getCustomer();
    getPurchaseList();
    getDeliveryData();
})

function getCustomer()
{
    let token = localStorage.getItem("token");
    if (!token) return;

    fetch("https://food-delivery.kreosoft.ru/api/account/profile", {
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    })
    .then((response) => {
        if (response.status == 401) localStorage.removeItem("token");
        return response.json();
    })
    .then((json) => {
        $("#customer-phone").val(json.phoneNumber);
        $("#customer-email").val(json.email);
        $("#customer-address").val(json.address);
    })
    .catch((error) => {
        console.log(error);
    })
}

function getPurchaseList()
{
    let token = localStorage.getItem("token");
    if (!token) return;

    $("#purchase-list").empty();

    fetch("https://food-delivery.kreosoft.ru/api/basket", {
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${token}`
    }
    })
    .then((response) => {
        if (response.status == 401) localStorage.removeItem("token");
        return response.json();
    })
    .then((json) => {
        if (!json.length) $(".purchase-card").addClass("d-none");
        let template = $(".purchase-template");
        let finalPrice = 0;
        for (let dish of json)
        {
            let block = template.clone();
            block.attr("purchase_main_id", dish.id);
            block.find(".img-purchase").attr("src", dish.image);
            block.find(".purchase-name").text(dish.name);
            block.find(".purchase-price").text("Цена: " + dish.price + " руб.");
            block.find(".purchase-amount").text("Количество: " + dish.amount + " шт.");
            block.find(".purchase-totalprice").text(dish.totalPrice + " руб.");
            finalPrice += dish.totalPrice;
            block.removeClass("d-none");
            $("#purchase-list").append(block);
        }
        $(".purchase-finalprice").text(finalPrice + " руб.");
    })
    .catch((error) => {
        console.log(error);
    })
}

function getDeliveryData()
{
    $("#customer-time").change(function() {
        var date = new Date();
        var dateString = new Date(date.getTime() - (date.getTimezoneOffset() * 60000)).toISOString().slice(0, -8);
        if (this.value < dateString) {
            this.value = dateString;
            alert("How are we supposed to deliver in the past?!");
        }
    })
}