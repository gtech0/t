import navbarFooterLoad from "./navbarFooterLoad.js";
import logout from "./login.js"

$(document).ready(function() {
    navbarFooterLoad();
    phoneMask();
    disablePassWhitespace();
    $("#reg-button").on('click', () => {
        if (finalCheck()) registration();
    })
});

function registration()
{
    console.log("Success");
    let fullName = $('#fio-reg').val();
    let password = $('#password-reg').val();
    let email = $('#email-input').val();
    let address = $('#address').val();
    let birthDate = $('#date-form').val();
    let gender = genderCheck();
    let phoneNumber = $('#phone-reg').val();
    
    fetch("https://food-delivery.kreosoft.ru/api/account/register", {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
    body: JSON.stringify({
        "fullName": fullName,
        "password": password,
        "email": email,
        "address": address,
        "birthDate": birthDate,
        "gender": gender,
        "phoneNumber": phoneNumber
    }),
    })
    .then((response) => {
        if (response.ok) {
            localStorage.setItem("token", json.token);
            window.location.reload();
        }
        else {
            alert("Registration failed");
        }
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}

function finalCheck()
{
    let check = nameCheck() + emailCheck() + phoneCheck() + passwordCheck() + dateCheck();
    if (check != 5) return 0;
    return 1;
}

function phoneMask() {
    $('#phone-reg').inputmask('+7 (999) 999-99-99', {"placeholder": "x", "clearMaskOnLostFocus": false});
}

function dateCheck() {
    
    var date = new Date();
    var dateString = new Date(date.getTime() - (date.getTimezoneOffset() * 60000)).toISOString().split("T")[0];

    if ($('#date-form').val() > dateString || !$('#date-form').val()) {
        $('#date-form').val(dateString);
        alert("You can't born in the future!");
        return 0;
    }
    return 1;
}

function emailCheck() {
    if (!$("#email-input").val().match(/^[a-z0-9._+-]+@[a-z0-9.-]+\.[a-z]+$/)) {
        alert("Incorrect email");
        return 0;
    }
    return 1;
}

function nameCheck() {
    let fio = $("#fio-reg").val().trim();
    $("#fio-reg").val(fio);
    if (!fio.match(/^[а-яА-Яa-zA-Z ]+$/)) {
        alert("Enter your full name");
        return 0;
    }
    return 1;
}

function genderCheck() {
    let gender = "Male";
    $("#gender-reg").change(function() {
        $("#gender-reg option:selected").each(function() {
            gender = $(this).val();
            if (gender == 0) gender = "Male";
            else gender = "Female";
        });
    }).trigger("change");
    return gender;
}

function phoneCheck()
{
    let phoneLen = $('#phone-reg').val().replace(/[^0-9]/g, "").length;
    if (![0, 11].includes(phoneLen)) {
        alert("Incorrect phone number");
        $('#phone-reg').val('');
        return 0;
    }
    return 1;
}

function passwordCheck()
{
    let passLen = String($('#password-reg').val()).length;
    if (passLen < 6) {
        alert("Password must be at least 6 symbols long");
        return 0;
    }
    return 1;
}

function disablePassWhitespace()
{
    $("#password-reg").keydown((e) => {
        if (e.which == 32)
            return false;
    });
}