import navbarFooterLoad from "./navbarFooterLoad.js";
import logout from "./login.js"

$(document).ready(function() {
    navbarFooterLoad();
    phoneMask();
    disablePassWhitespace();
    $("#reg-button").on('click', () => {
        if (finalCheck()) registration();
    })
});

function registration()
{
    console.log("Success");
    let fullName = $('#fio-reg').val();
    let password = $('#password-reg').val();
    let email = $('#email-input').val();
    let address = $('#address').val();
    let birthDate = $('#date-form').val();
    let gender = genderCheck();
    let phoneNumber = $('#phone-reg').val();
    
    fetch("https://food-delivery.kreosoft.ru/api/account/register", {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
    body: JSON.stringify({
        "fullName": fullName,
        "password": password,
        "email": email,
        "address": address,
        "birthDate": birthDate,
        "gender": gender,
        "phoneNumber": phoneNumber
    }),
    })
    .then((response) => {
        if (!response.ok) {
            alert("Registration failed");
            return;
        }
        return response.json()
    })
    .then((json) => {
        localStorage.setItem("token", json.token);
        localStorage.setItem("username", email);
        window.location.href="index.html";
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}

function finalCheck()
{
    let check = nameCheck() + emailCheck() + phoneCheck() + passwordCheck() + dateCheck();
    if (check != 5) return 0;
    return 1;
}

function phoneMask() {
    $('#phone-reg').inputmask('+7 (999) 999-99-99', {"placeholder": "x", "clearMaskOnLostFocus": false});

    $('#phone-reg').hover(function(){
        $(this).removeClass('text-muted');
    }, function(e) {
        $(this).addClass('text-muted');
    });
}

function dateCheck() {
    
    var date = new Date();
    var dateString = new Date(date.getTime() - (date.getTimezoneOffset() * 60000)).toISOString().split("T")[0];
    if ($('#date-form').val() > dateString || !$('#date-form').val()) {
        $('#date-form').val(dateString);
        $("#date-form").removeClass("is-valid");
        $("#date-form").addClass("is-invalid");
        return 0;
    }
    $("#date-form").removeClass("is-invalid");
    $("#date-form").addClass("is-valid");
    return 1;
}

function emailCheck() {
    if (!$("#email-input").val().match(/^[a-z0-9._+-]+@[a-z0-9.-]+\.[a-z]+$/)) {
        $("#email-input").removeClass("is-valid");
        $("#email-input").addClass("is-invalid");
        return 0;
    }
    $("#email-input").removeClass("is-invalid");
    $("#email-input").addClass("is-valid");
    return 1;
}

function nameCheck() {
    let fio = $("#fio-reg").val().trim();
    $("#fio-reg").val(fio);
    if (!fio.match(/^[а-яА-Яa-zA-Z ]+$/)) {
        $("#fio-reg").removeClass("is-valid");
        $("#fio-reg").addClass("is-invalid");
        return 0;
    }
    $("#fio-reg").removeClass("is-invalid");
    $("#fio-reg").addClass("is-valid");
    return 1;
}

function genderCheck() {
    let gender = "Male";
    $("#gender-reg").change(function() {
        $("#gender-reg option:selected").each(function() {
            gender = $(this).val();
            if (gender == 0) gender = "Male";
            else gender = "Female";
        });
    }).trigger("change");
    return gender;
}

function phoneCheck()
{
    let phoneLen = $('#phone-reg').val().replace(/[^0-9]/g, "").length;
    if (![11].includes(phoneLen)) {
        $("#phone-reg").removeClass("is-valid");
        $("#phone-reg").addClass("is-invalid");
        return 0;
    }
    $("#phone-reg").removeClass("is-invalid");
    $("#phone-reg").addClass("is-valid");
    return 1;
}

function passwordCheck()
{
    let passLen = String($('#password-reg').val()).length;
    if (passLen < 6) {
        $("#password-reg").removeClass("is-valid");
        $("#password-reg").addClass("is-invalid");
        return 0;
    }
    $("#password-reg").removeClass("is-invalid");
    $("#password-reg").addClass("is-valid");
    return 1;
}

function disablePassWhitespace()
{
    $("#password-reg").keydown((e) => {
        if (e.which == 32)
            return false;
    });
}