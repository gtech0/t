document.addEventListener("click", (event) => {
    const {target} = event;
    if(!target.matches("nav a")) {
        return;
    }
    event.preventDefault();
    urlRoute();
})

const urlRoutes = {
    "404": "/404.html",
    "/": "/index.html",
    "/login": "/login.html",
    "/registration": "/registration.html",
    "/profile": "/profile.html",
    "/item": "/item.html",
    "/cart": "/cart.html",
    "/orders": "/orders.html",
    "/order": "/order.html",
    "/purchase": "/purchase.html"
}

const urlRoute = (event) => {
    event = event || window.event;
    event.preventDefault();
    window.history.pushState(null, null, event.target.href);
    console.log(event.target.href);
    urlLocationHandler();
}

const urlLocationHandler = async () => {
    const location = window.location.pathname;
    if (location == "") location = "/";
}

window.onpopstate = urlLocationHandler;
window.route = urlRoute;
urlLocationHandler();